package Tests;

import java.util.List;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utils.*;


public class Test1 {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\tamasn\\Desktop\\selenium\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 15);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		DOMConfigurator.configure("log4j.xml");
		
		Log.info("Config done!");
		
		Log.startTestCase("Search functionality");
		
		
		driver.get("https://www.autohero.com/de/search/");
		Log.info("Webpage opened!");
		Utils.Utility.select_MarkeModel(driver, wait, "Volkswagen", "Golf");
		Log.info("Marke and Model selected!");
		Utils.Utility.set_Mileage(driver, wait, null, "25.000");
		Log.info("Max milage set!");
		Thread.sleep(5000);
		
		int resultCount= driver.findElements(By.xpath("//div[@class='ReactVirtualized__Grid__innerScrollContainer']/div")).size();
		int resultCountCorrect= driver.findElements(By.xpath("//div[@class=contains(@class, 'infoContainer')]//h2[contains(text(), 'Volkswagen Golf')]")).size();
		
		boolean markeModelOK = true;
		
		if(resultCount != resultCountCorrect){
			Log.error("Marke and Model results are not correct!");
			markeModelOK = false;
		}
		Log.info("Total found results: " + resultCount + " Total found correct results based on Marke and Model: " + resultCountCorrect);
		
		boolean mileageOK = true;
		List<WebElement> mileage = driver.findElements(By.xpath("//div[@class=contains(@class, 'infoContainer')]//ul[@class=contains(@class, 'specList')]/li"));
		
		for(WebElement element : mileage) {
			
			String innertext = element.getText();
			
			if (innertext.endsWith("km")) {
				int index = innertext.indexOf(" km");
				String actualMileage= innertext.substring(2, index).replace(".", "");
				Log.info("Actual Mileage is: " + actualMileage);
				
				int mileageNumber= Integer.parseInt(actualMileage);
				
				if(mileageNumber > 25000) {
					Log.error("Mileage filter did not work properly, actual mileage: "  + actualMileage);
					mileageOK = false;
				}
			}
		}
		
		if(markeModelOK == true  && mileageOK == true){
			Log.info("Marke, Model and Mileage criteria results are correct");
			Log.endTestCasePassed("Test1");
		} else {
			Log.info("Marke, Model and Mileage criteria results are NOT correct!");
			Log.endTestCaseFailed("Test1");
		}
		
		driver.quit();
		
	}
}
