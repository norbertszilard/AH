package Utils;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Utility {
	
	private static WebElement element = null;
	
public static void select_MarkeModel(WebDriver driver, WebDriverWait wait, String marke, String model) {
		
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='carMakeFilter']")));
			element = driver.findElement(By.xpath("//button[@id='carMakeFilter']"));
			if (element != null) {
				element.click();
			}
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h3[text()='Andere Marken']//following-sibling::ul//input[@value='"+marke+"']")));
			element = driver.findElement(By.xpath("//h3[text()='Andere Marken']//following-sibling::ul//input[@value='"+marke+"']"));
			if (element != null) {
				element.click();
			}
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='"+model+"']")));
			element = driver.findElement(By.xpath("//input[@value='"+model+"']"));
			if (element != null) {
				element.click();
			}
			
			
		} catch (Exception e) {
			Log.fatal("Model or Marke could not be selected!");
		}
	}

public static void set_Mileage(WebDriver driver, WebDriverWait wait, String Ab, String Bis) {
	try {
		Thread.sleep(2000);
		boolean isBasicDisplayed = false;
		//I had to make a difference here, because the appearance differs regarding the display/window size
		List<WebElement> basicDisplayed = driver.findElements(By.xpath("//button[@id='basicFilter']"));
		if (basicDisplayed.size() != 0) {
			driver.findElement(By.xpath("//button[@id='basicFilter']")).click();
			isBasicDisplayed = true;
		} else {
			driver.findElement(By.xpath("//button[@id='mileageFilter']")).click();
		}

		
		if(Ab!=null) {
			
			if (isBasicDisplayed==true) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='Kilometer']//following-sibling::div//div[text()='Ab']//following-sibling::select")));
				driver.findElement(By.xpath("//div[text()='Kilometer']//following-sibling::div//div[text()='Ab']//following-sibling::select")).click();
				
			} else {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='rangeStart']")));
				driver.findElement(By.xpath("//select[@id='rangeStart']")).click();
				
			}
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='rangeStart']//option[text()='"+Ab+" km']")));
			driver.findElement(By.xpath("//select[@id='rangeStart']//option[text()='"+Ab+" km']")).click();
			
		}
		
		if(Bis!=null) {
			
			if (isBasicDisplayed==true) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='Kilometer']//following-sibling::div//div[text()='Bis']//following-sibling::select")));
				driver.findElement(By.xpath("//div[text()='Kilometer']//following-sibling::div//div[text()='Bis']//following-sibling::select")).click();
				
			} else {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='rangeStart']")));
				driver.findElement(By.xpath("//select[@id='rangeStart']")).click();
				
			}
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='rangeEnd']//option[text()='"+Bis+" km']")));
			driver.findElement(By.xpath("//select[@id='rangeEnd']//option[text()='"+Bis+" km']")).click();

		}
		
		if (isBasicDisplayed==true) {
			driver.findElement(By.xpath("//button[@id='basicFilter']")).click();
		}else {
			driver.findElement(By.xpath("//button[@id='mileageFilter']")).click();
		}
		
	} catch (Exception e) {
		Log.fatal("Milage could not be selected!");
	}
}

public  Integer parseIntOrNull(String value) {
    try {
        return Integer.parseInt(value);
    } catch (NumberFormatException e) {
        return null;
    }
}

}
